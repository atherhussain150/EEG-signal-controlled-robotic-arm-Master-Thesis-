
clear 
clc
close all

%%
data_version='22.11.03'; % '11.11.22' % '03112022' % 22.11.24 / %22.11.28 / %22.11.03 / %22.11.11 / %22.12.15 / %22.12.13

Sce_re='Pull';  
a_Control_Panel_eeg_read

Sce_re='Nothing';  
a_Control_Panel_eeg_read

Sce_re='Push';  
a_Control_Panel_eeg_read

h_Size_re_unit_new

disp('Wir sind fertig!!!')
